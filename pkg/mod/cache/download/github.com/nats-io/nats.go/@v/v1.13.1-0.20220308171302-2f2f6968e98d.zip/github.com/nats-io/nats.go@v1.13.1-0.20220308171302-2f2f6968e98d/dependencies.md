# External Dependencies

This file lists the dependencies used in this repository.

| Dependency | License |
|-|-|
| Go | BSD 3-Clause "New" or "Revised" License |
| github.com/nats-io/nats.go | Apache License 2.0 |
| github.com/golang/protobuf v1.4.2 | BSD 3-Clause "New" or "Revised" License |
| github.com/nats-io/nats-server/v2 v2.1.8-0.20201115145023-f61fa8529a0f | Apache License 2.0 |
| github.com/nats-io/nkeys v0.2.0 | Apache License 2.0 |
| github.com/nats-io/nuid v1.0.1 | Apache License 2.0 |
| google.golang.org/protobuf v1.23.0 | BSD 3-Clause License |
