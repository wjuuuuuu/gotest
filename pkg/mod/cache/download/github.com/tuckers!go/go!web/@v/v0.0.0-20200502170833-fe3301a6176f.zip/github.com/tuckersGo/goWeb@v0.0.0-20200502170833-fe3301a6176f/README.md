Web made by Go
==============================

This is "Go in Web" lecture source codes.
https://www.youtube.com/playlist?list=PLy-g2fnSzUTDALoERcKDniql16SAaQYHF

Installation
------------

	$ go get github.com/tuckersGo/goWeb