### Issue Description

### Checklist

- [ ] Dependencies installed
- [ ] No typos
- [ ] Searched existing issues and docs

### Expected behaviour

### Actual behaviour

### Steps to reproduce

### Working code to debug

```go
package main

func main() {
}
```

### Version/commit
