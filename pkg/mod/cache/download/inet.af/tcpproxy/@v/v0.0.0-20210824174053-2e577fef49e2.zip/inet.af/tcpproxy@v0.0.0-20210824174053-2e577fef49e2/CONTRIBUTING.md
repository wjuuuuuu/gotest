Contributions are welcome by pull request.

You need to sign the Google Contributor License Agreement before your
contributions can be accepted. You can find the individual and organization
level CLAs here:

Individual: https://cla.developers.google.com/about/google-individual
Organization: https://cla.developers.google.com/about/google-corporate
